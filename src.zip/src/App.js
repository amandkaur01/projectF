import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import "./styles/main.css";   // ✅ Import all styles

import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import EquipmentList from "./pages/EquipmentList";
import AddEquipment from "./pages/AddEquipment";
import BorrowEquipment from "./pages/BorrowEquipment";
import StudentDashboard from "./pages/StudentDashboard";
import BorrowRecords from "./pages/BorrowRecords";
import ReturnPage from "./pages/ReturnPage";
import StudentHistory from "./pages/StudentHistory";

function App() {

  return (

    <Router>

      <Routes>

        {/* Authentication */}
        <Route path="/" element={<Login />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />

        {/* Admin */}
        <Route path="/admin" element={<Dashboard />} />
        <Route path="/add-equipment" element={<AddEquipment />} />
        <Route path="/equipment" element={<EquipmentList />} />

        {/* Borrow */}
        <Route path="/borrow" element={<BorrowEquipment />} />
        <Route path="/borrow-records" element={<BorrowRecords />} />

        {/* Student */}
        <Route path="/student" element={<StudentDashboard />} />
        <Route path="/return" element={<ReturnPage />} />
        <Route path="/student-history" element={<StudentHistory />} />

      </Routes>

    </Router>

  );
}

export default App;