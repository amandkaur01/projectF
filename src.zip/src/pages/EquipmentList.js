import React, { useEffect, useState } from "react";
import API from "../services/api";

function EquipmentList() {

  const [equipment, setEquipment] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {

    API.get("/equipment")
      .then(res => {
        setEquipment(res.data);
      })
      .catch(err => {
        console.log(err);
      });

  }, []);

  // Filter equipment
  const filteredEquipment = equipment.filter(e =>
    e.name.toLowerCase().includes(search.toLowerCase()) ||
    e.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="page-container">

      <h2>Equipment List</h2>

      {/* Search Bar */}

      <input
        type="text"
        placeholder="Search equipment..."
        className="input"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <div className="card">

      <table className="table table-bordered mt-4">

<thead>
<tr>
<th>S.No</th>
<th>Name</th>
<th>Category</th>
<th>Total Quantity</th>
<th>Available</th>
<th>Location</th>
</tr>
</thead>

<tbody>

{filteredEquipment.length === 0 ? (
<tr>
<td colSpan="6" style={{ textAlign: "center" }}>
No Equipment Found
</td>
</tr>
) : (

filteredEquipment.map((e, index) => (
<tr key={e.id}>

<td>{index + 1}</td>

<td>{e.name}</td>
<td>{e.category}</td>
<td>{e.totalQuantity}</td>
<td>{e.availableQuantity}</td>
<td>{e.location}</td>

</tr>
))

)}

</tbody>

</table>

      </div>

    </div>
  );
}

export default EquipmentList;