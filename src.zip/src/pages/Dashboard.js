import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import axios from "axios";

function Dashboard() {

  const navigate = useNavigate();

  const [analysis, setAnalysis] = useState("");
  const [recommendation, setRecommendation] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");

  const [stats, setStats] = useState({
    totalEquipment: 0,
    borrowed: 0,
    overdue: 0
  });

  const getUsageAnalysis = () => {
    axios.get("http://localhost:8080/api/ai/usage-analysis")
      .then(res => setAnalysis(res.data))
      .catch(err => console.log(err));
  };

  const getRecommendation = () => {
    axios.get("http://localhost:8080/api/ai/recommendation")
      .then(res => setRecommendation(res.data))
      .catch(err => console.log(err));
  };

  const askAI = () => {
    axios.post("http://localhost:8080/api/ai/chat", {
      question: question
    })
      .then(res => setAnswer(res.data))
      .catch(err => console.log(err));
  };

  useEffect(() => {
    API.get("/dashboard")
      .then(res => setStats(res.data))
      .catch(err => console.log(err));
  }, []);

  const cardStyle = {
    width: "260px",
    background: "#ffffff",
    padding: "25px",
    borderRadius: "12px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
    textAlign: "center",
    borderBottom: "6px solid #1b7268",
    transition: "0.3s"
  };

  const buttonStyle = {
    backgroundColor: "#1b7268",
    color: "white",
    border: "none",
    padding: "10px 18px",
    borderRadius: "8px"
  };

  return (
    <div className="container mt-4">

      <h1 style={{ textAlign: "center", marginBottom: "40px" }}>
        Admin Dashboard
      </h1>

      {/* Analytics Cards */}
      <div style={{
        display: "flex",
        justifyContent: "center",
        gap: "40px",
        flexWrap: "wrap"
      }}>

        <div style={cardStyle}>
          <h4>Total Equipment</h4>
          <h1 style={{ color: "#1b7268" }}>{stats.totalEquipment}</h1>
        </div>

        <div style={cardStyle}>
          <h4>Borrowed Equipment</h4>
          <h1 style={{ color: "#1b7268" }}>{stats.borrowed}</h1>
        </div>

        <div style={cardStyle}>
          <h4>Overdue Equipment</h4>
          <h1 style={{ color: "#1b7268" }}>{stats.overdue}</h1>
        </div>

      </div>

      {/* Admin Actions */}
      <div style={{
        marginTop: "50px",
        textAlign: "center"
      }}>

        <button
          className="btn m-2"
          style={buttonStyle}
          onClick={() => navigate("/equipment")}
        >
          View Equipment
        </button>

        <button
          className="btn m-2"
          style={buttonStyle}
          onClick={() => navigate("/add-equipment")}
        >
          Add Equipment
        </button>

        <button
          className="btn m-2"
          style={buttonStyle}
          onClick={() => navigate("/borrow-records")}
        >
          Borrow Records
        </button>

      </div>

      {/* AI Section */}

      <div style={{ marginTop: "60px", textAlign: "center" }}>

        <h2>AI Lab Insights 🤖</h2>

        <button className="btn m-2" style={buttonStyle} onClick={getUsageAnalysis}>
          Generate Usage Analysis
        </button>

        <p>{analysis}</p>

        <button className="btn m-2" style={buttonStyle} onClick={getRecommendation}>
          Get Purchase Recommendation
        </button>

        <p>{recommendation}</p>

        <h3>AI Assistant</h3>

        <input
          type="text"
          placeholder="Ask about equipment..."
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          style={{
            padding: "10px",
            width: "300px",
            borderRadius: "6px",
            border: "1px solid #ccc",
            marginRight: "10px"
          }}
        />

        <button className="btn m-2" style={buttonStyle} onClick={askAI}>
          Ask AI
        </button>

        <p style={{ marginTop: "10px" }}>{answer}</p>

      </div>

    </div>
  );
}

export default Dashboard;

