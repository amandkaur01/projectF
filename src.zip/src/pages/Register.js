import React, { useState } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";

function Register() {

  const navigate = useNavigate();

  const [user, setUser] = useState({
    name: "",
    email: "",
    password: "",
    role: "STUDENT"
  });

  const handleChange = (e) => {

    setUser({
      ...user,
      [e.target.name]: e.target.value
    });

  };

  const handleRegister = async (e) => {

    e.preventDefault();

    try {

      await API.post("/auth/register", user);

      alert("Registration Successful");

      navigate("/login");

    } catch (error) {
      console.log(error);
      alert("Registration Failed");
    }

  };

  return (
    <div style={{ width: "400px", margin: "100px auto" }}>

      <h2>Register</h2>

      <form onSubmit={handleRegister}>

        <input
          name="name"
          placeholder="Name"
          className="form-control mb-3"
          onChange={handleChange}
        />

        <input
          name="email"
          placeholder="Email"
          className="form-control mb-3"
          onChange={handleChange}
        />

        <input
          name="password"
          type="password"
          placeholder="Password"
          className="form-control mb-3"
          onChange={handleChange}
        />

        <select
          name="role"
          className="form-control mb-3"
          onChange={handleChange}
        >

          <option value="STUDENT">Student</option>
          <option value="ADMIN">Admin</option>

        </select>

        <button className="btn btn-success w-100">
          Register
        </button>
         <p style={{marginTop:"10px"}}>
  Already have an account? <a href="/login">Login here</a>
</p>
      </form>

    </div>
  );
}

export default Register;