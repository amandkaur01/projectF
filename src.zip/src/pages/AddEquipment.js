import React, { useState } from "react";
import API from "../services/api";

function AddEquipment() {

  const [equipment, setEquipment] = useState({
    name: "",
    category: "",
    totalQuantity: "",
    availableQuantity: "",
    location: ""
  });

  const handleChange = (e) => {

    setEquipment({
      ...equipment,
      [e.target.name]: e.target.value
    });

  };

  const handleSubmit = async (e) => {

    e.preventDefault();

    try {

      await API.post("/equipment", equipment);

      alert("Equipment Added Successfully");

    } catch (error) {

      console.log(error);

    }

  };

  return (
    <div className="container mt-4">

      <h2>Add Equipment</h2>

      <form onSubmit={handleSubmit}>

        <input
          name="name"
          placeholder="Equipment Name"
          className="form-control mb-3"
          onChange={handleChange}
        />

        <input
          name="category"
          placeholder="Category"
          className="form-control mb-3"
          onChange={handleChange}
        />

        <input
          name="totalQuantity"
          placeholder="Total Quantity"
          className="form-control mb-3"
          onChange={handleChange}
        />


        <input
          name="location"
          placeholder="Location"
          className="form-control mb-3"
          onChange={handleChange}
        />

        <button className="btn btn-success">
          Add Equipment
        </button>

      </form>

    </div>
  );
}

export default AddEquipment;