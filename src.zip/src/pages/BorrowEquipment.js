import React, { useEffect, useState } from "react";
import API from "../services/api";

function BorrowEquipment() {

  const [equipmentList, setEquipmentList] = useState([]);

  const [borrow, setBorrow] = useState({
    studentName: "",
    equipmentName: "",
    quantity: ""
  });

  useEffect(() => {

  API.get("/equipment")
    .then(res => setEquipmentList(res.data))
    .catch(err => console.log(err));

  const user = JSON.parse(localStorage.getItem("user"));

  if (user) {
    setBorrow(prev => ({
      ...prev,
      studentName: user.name.trim().toLowerCase()
    }));
  }

}, []);

  const handleChange = (e) => {

    setBorrow({
      ...borrow,
      [e.target.name]: e.target.value
    });

  };

  const handleSubmit = async (e) => {

    e.preventDefault();

    try {

      await API.post("/borrow", borrow);

      alert("Equipment Borrowed Successfully");

      setBorrow({
        studentName: borrow.studentName,
        equipmentName: "",
        quantity: ""
      });

    } catch (error) {

      console.log(error);
      alert("Borrow Failed");

    }

  };

  return (
    <div className="container mt-4">

      <h2>Borrow Equipment</h2>

      <form onSubmit={handleSubmit}>

        <input
          name="studentName"
          value={borrow.studentName}
          className="form-control mb-3"
          readOnly
        />

        <select
          name="equipmentName"
          className="form-control mb-3"
          value={borrow.equipmentName}
          onChange={handleChange}
        >
          <option value="">Select Equipment</option>

          {equipmentList.map(e => (
            <option key={e.id} value={e.name}>
              {e.name}
            </option>
          ))}

        </select>

        <input
          name="quantity"
          placeholder="Quantity"
          className="form-control mb-3"
          value={borrow.quantity}
          onChange={handleChange}
        />

        <button className="btn btn-primary">
          Borrow
        </button>

      </form>

    </div>
  );
}

export default BorrowEquipment;