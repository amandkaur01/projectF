import React, { useEffect, useState } from "react";
import API from "../services/api";

function BorrowRecords() {

  const [records, setRecords] = useState([]);

  useEffect(() => {

    API.get("/borrow")
      .then(res => {
        setRecords(res.data);
      })
      .catch(err => console.log(err));

  }, []);

  return (

    <div className="container mt-4">

      <h2 style={{ textAlign: "center" }}>Borrow Records</h2>

      <table className="table table-bordered mt-4">

        <thead>
          <tr>
            <th>Student Name</th>
            <th>Equipment</th>
            <th>Borrowed</th>
            <th>Returned</th>
            <th>Borrow Date</th>
            <th>Due Date</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>

        {records.length === 0 ? (
          <tr>
            <td colSpan="7" style={{ textAlign: "center" }}>
              No Borrow Records
            </td>
          </tr>
        ) : (
          records.map(b => (
            <tr key={b.id}>
              <td>{b.studentName}</td>
              <td>{b.equipmentName}</td>
              <td>{b.quantity}</td>
              <td>{b.returnedQuantity}</td>
              <td>{b.borrowDate}</td>
              <td>{b.dueDate}</td>

              <td>
                <span className={`badge 
                  ${b.status === "BORROWED" ? "bg-warning" :
                    b.status === "PARTIAL" ? "bg-info" :
                    b.status === "OVERDUE" ? "bg-danger" :
                    "bg-success"}`}>
                  {b.status}
                </span>
              </td>

            </tr>
          ))
        )}

        </tbody>

      </table>

    </div>

  );
}

export default BorrowRecords;