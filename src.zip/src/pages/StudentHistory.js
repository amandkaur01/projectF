import React, { useEffect, useState } from "react";
import API from "../services/api";

function StudentHistory() {

  const [history, setHistory] = useState([]);

  useEffect(() => {

    const user = JSON.parse(localStorage.getItem("user"));

    if (user) {
      API.get(`/borrow/student/${user.name.trim().toLowerCase()}`)
        .then(res => {
          setHistory(res.data);
        })
        .catch(err => {
          console.log(err);
        });
    }

  }, []);

  return (
    <div className="container mt-4">

      <h2>Student Borrow History</h2>

      <table className="table table-bordered mt-4">

       <thead>
<tr>
<th>Borrow ID</th>
<th>Equipment</th>
<th>Borrowed</th>
<th>Returned</th>
<th>Borrow Date</th>
<th>Due Date</th>
<th>Status</th>
</tr>
</thead>

<tbody>

{history.length === 0 ? (
  <tr>
    <td colSpan="5" style={{ textAlign: "center" }}>
      No Borrow Records
    </td>
  </tr>

) : (
  history.map(b => (
    <tr key={b.id}>
<td>{b.id}</td>
<td>{b.equipmentName}</td>
<td>{b.quantity}</td>
<td>{b.returnedQuantity}</td>
<td>{b.borrowDate}</td>
<td>{b.dueDate}</td>

<td>
<span className={`badge 
${b.status === "BORROWED" ? "bg-warning" :
b.status === "PARTIAL" ? "bg-info" :
b.status === "OVERDUE" ? "bg-danger" :
"bg-success"}`}>
{b.status}
</span>
</td>

</tr>
  ))
)}

</tbody>

      </table>

    </div>
  );
}

export default StudentHistory;