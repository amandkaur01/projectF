import React, { useState } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";

function Login() {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const handleLogin = async (e) => {

    e.preventDefault();

    try {

      const response = await API.post("/auth/login", {
        email: email,
        password: password
      });

      const user = response.data;

      if (!user) {
        alert("Invalid Credentials");
        return;
      }

      // store full user object
      localStorage.setItem("user", JSON.stringify(user));

      // store student name separately (for borrow history)
      localStorage.setItem("studentName", user.name);

      // navigate based on role
      if (user.role === "ADMIN") {
        navigate("/admin");
      } else {
        navigate("/student");
      }

    } catch (error) {

      console.log(error);
      alert("Login Failed");

    }

  };

  return (
    <div style={{ width: "400px", margin: "100px auto" }}>

      <h2>Login</h2>

      <form onSubmit={handleLogin}>

        <input
          type="email"
          placeholder="Email"
          className="form-control mb-3"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <input
          type="password"
          placeholder="Password"
          className="form-control mb-3"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <button className="btn btn-primary w-100">
          Login
        </button>

        <p style={{ marginTop: "10px" }}>
          New user? <a href="/register">Register here</a>
        </p>

      </form>

    </div>
  );
}

export default Login;