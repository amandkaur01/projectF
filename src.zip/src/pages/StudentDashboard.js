import React from "react";
import { useNavigate } from "react-router-dom";

function StudentDashboard() {

  const navigate = useNavigate();

  const cardStyle = {
    background: "#e8e8e8",
    padding: "30px",
    borderRadius: "10px",
    width: "250px",
    textAlign: "center",
    fontSize: "22px",
    fontWeight: "500",
    color: "#0b5d5d",
    boxShadow: "0 6px 0 #1b7a78"
  };

  const buttonStyle = {
    backgroundColor: "#1b7a78",
    color: "white",
    border: "none",
    padding: "12px 20px",
    margin: "10px",
    borderRadius: "8px",
    fontSize: "16px",
    cursor: "pointer"
  };

  return (
    <div style={{ padding: "40px", textAlign: "center" }}>

      <h1 style={{ color: "#0b5d5d" }}>Student Dashboard</h1>

      <div style={{
        display: "flex",
        justifyContent: "center",
        gap: "40px",
        marginTop: "40px"
      }}>

        <div style={cardStyle}>
          Available Equipment
        </div>

        <div style={cardStyle}>
          Borrow Equipment
        </div>

        <div style={cardStyle}>
          Return Equipment
        </div>

        <div style={cardStyle}>
          Student History
        </div>

      </div>

      <h2 style={{ marginTop: "60px" }}>Student Actions</h2>

      <div style={{ marginTop: "20px" }}>

        <button
          style={buttonStyle}
          onClick={() => navigate("/equipment")}
        >
          Available Equipment
        </button>

        <button
          style={buttonStyle}
          onClick={() => navigate("/borrow")}
        >
          Borrow Equipment
        </button>

        <button
          style={buttonStyle}
          onClick={() => navigate("/return")}
        >
          Return Equipment
        </button>

        <button
          style={buttonStyle}
          onClick={() => navigate("/student-history")}
        >
          Student History
        </button>

      </div>

    </div>
  );
}

export default StudentDashboard;