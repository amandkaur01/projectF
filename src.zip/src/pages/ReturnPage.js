import React, { useState } from "react";
import API from "../services/api";

function ReturnPage() {

  const [borrowId, setBorrowId] = useState("");
  const [quantity, setQuantity] = useState("");
  const [message, setMessage] = useState("");

  const handleReturn = async () => {

    try {

      await API.put(`/borrow/return/${borrowId}/${quantity}`);

      setMessage("Equipment returned successfully");

    } catch (error) {

      console.log(error);
      setMessage("Error returning equipment");

    }

  };

  return (
    <div style={{ padding: "40px" }}>

      <h2>Return Equipment</h2>

      <input
        type="number"
        placeholder="Borrow ID"
        value={borrowId}
        onChange={(e) => setBorrowId(e.target.value)}
      />

      <br /><br />

      <input
        type="number"
        placeholder="Quantity to Return"
        value={quantity}
        onChange={(e) => setQuantity(e.target.value)}
      />

      <br /><br />

      <button onClick={handleReturn}>
        Return Equipment
      </button>

      <p>{message}</p>

    </div>
  );
}

export default ReturnPage;