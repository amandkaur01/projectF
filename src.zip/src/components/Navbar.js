import React from "react";
import { Link } from "react-router-dom";

function Navbar() {
  return (
    <nav className="navbar navbar-dark bg-dark navbar-expand-lg">
      <div className="container-fluid">

        <span className="navbar-brand">
          Smart IoT Lab Equipment System
        </span>

        <div className="navbar-nav">

          <Link className="nav-link text-white" to="/">
            Dashboard
          </Link>

          <Link className="nav-link text-white" to="/equipment">
            Equipment List
          </Link>

        </div>

      </div>
    </nav>
  );
}

export default Navbar;